### Hosted on the CloudBolt Content Library

This sample content is not intended for direct consumption.  Please use the Content
Library feature within CloudBolt to import the Jenkins blueprint.
