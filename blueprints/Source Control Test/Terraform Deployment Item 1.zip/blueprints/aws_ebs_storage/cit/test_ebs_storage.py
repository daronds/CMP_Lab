import json
import logging
import re

from api.api_samples.python_client.api_client import CloudBoltAPIClient
from api.api_samples.python_client.samples.api_helpers import wait_for_order_completion
from common.methods import set_progress
from servicecatalog.models import ServiceBlueprint
from utilities.exceptions import CloudBoltException
from utilities.models import ConnectionInfo
from orders.models import Order

# suppress logging from requests module
logger = logging.getLogger('requests')
logger.setLevel(40)
logger = logging.getLogger('py.warnings')
logger.setLevel(40)

API_CLIENT_CI = "CIT API Client"

BLUEPRINT = 26

BP_PAYLOADS = ["""
{
    "group": "/api/v2/groups/GRP-w0qe6tkf/",
    "items": {
        "deploy-items": [
            {
                "blueprint": "/api/v2/blueprints/BP-7ccir2js/",
                "blueprint-items-arguments": {
                    "build-item-Create AWS EBS Storage Volume": {
                        "parameters": {
                            "encrypted-a139": "False",
                            "env-id-a139": "6",
                            "volume-size-gb-a139": "500",
                            "volume-type-a139": "sc1"
                        }
                    }
                },
                "resource-name": "AWS EBS Storage",
                "resource-parameters": {}
            }
        ]
    },
    "submit-now": "true"
}
""",
"""
{
    "group": "/api/v2/groups/GRP-w0qe6tkf/",
    "items": {
        "deploy-items": [
            {
                "blueprint": "/api/v2/blueprints/BP-7ccir2js/",
                "blueprint-items-arguments": {
                    "build-item-Create AWS EBS Storage Volume": {
                        "parameters": {
                            "encrypted-a139": "False",
                            "env-id-a139": "6",
                            "volume-size-gb-a139": "1",
                            "volume-type-a139": "gp2"
                        }
                    }
                },
                "resource-name": "AWS EBS Storage",
                "resource-parameters": {}
            }
        ]
    },
    "submit-now": "true"
}
""",
"""
{
    "group": "/api/v2/groups/GRP-w0qe6tkf/",
    "items": {
        "deploy-items": [
            {
                "blueprint": "/api/v2/blueprints/BP-7ccir2js/",
                "blueprint-items-arguments": {
                    "build-item-Create AWS EBS Storage Volume": {
                        "parameters": {
                            "encrypted-a139": "False",
                            "env-id-a139": "6",
                            "volume-size-gb-a139": "1",
                            "volume-type-a139": "standard"
                        }
                    }
                },
                "resource-name": "AWS EBS Storage",
                "resource-parameters": {}
            }
        ]
    },
    "submit-now": "true"
}
""",
"""
{
    "group": "/api/v2/groups/GRP-w0qe6tkf/",
    "items": {
        "deploy-items": [
            {
                "blueprint": "/api/v2/blueprints/BP-7ccir2js/",
                "blueprint-items-arguments": {
                    "build-item-Create AWS EBS Storage Volume": {
                        "parameters": {
                            "encrypted-a139": "False",
                            "env-id-a139": "6",
                            "volume-size-gb-a139": "500",
                            "volume-type-a139": "st1"
                        }
                    }
                },
                "resource-name": "AWS EBS Storage",
                "resource-parameters": {}
            }
        ]
    },
    "submit-now": "true"
}
"""
]

def get_order_id_from_href(order_href):
    mo = re.search("/orders/([0-9]+)", order_href)
    return int(mo.groups()[0])


def test_order_blueprint(client):
    orders_ids = []

    for BP_PAYLOAD in BP_PAYLOADS:
        set_progress(type(BP_PAYLOAD))
        order = json.loads(client.post('/api/v2/orders/', body=BP_PAYLOAD))
        order_href = order['_links']['self']['href']
        order_id = get_order_id_from_href(order_href)
        result = wait_for_order_completion(client, order_id, 180, 10)
        if result != 0:
            raise CloudBoltException("Blueprint Deployment order {} did not succeed.".format(order_id))
        set_progress("Blueprint deployment order {} completed successfully.".format(order_id))
        orders_ids.append(order_id)
    return orders_ids


def test_delete_resource(client, resource):
    body = "{}"
    delete = json.loads(client.post(
        '/api/v2/resources/{}/{}/actions/1/'.format(resource.resource_type.name, resource.id), body=body))


def get_api_client():
    ci = ConnectionInfo.objects.get(name=API_CLIENT_CI)
    return CloudBoltAPIClient(
        ci.username, ci.password, ci.ip, ci.port, protocol=ci.protocol)


def run(job, *args, **kwargs):
    bp = ServiceBlueprint.objects.get(id=BLUEPRINT)
    set_progress(
        "Running Continuous Infrastructure Test for blueprint {}".format(bp)
    )

    client = get_api_client()

    # Order the BP
    set_progress("### ORDERING BLUEPRINT ###", tasks_done=0, total_tasks=3)
    orders_ids = test_order_blueprint(client)
    ebs_volume_ids = []

    for order_id in orders_ids:
        order = Order.objects.get(id=order_id)
        resource = order.orderitem_set.first().cast().get_resource()
    
        ebs_volume_id = resource.ebs_volume_id
        ebs_volume_ids.append(ebs_volume_id)

        # Delete the resource from the database only
        resource.delete()

    set_progress("### DISCOVERING RESOURCES FOR BLUEPRINT ###", tasks_done=1)
    bp.sync_resources()

    # should be able to get the resource since the sync should have created it
    resources = bp.resource_set.filter(name__icontains='EBS Volume - ', lifecycle='ACTIVE', blueprint=bp)

    [test_delete_resource(client, resource) for resource in resources if resource.ebs_volume_id in ebs_volume_ids]

    set_progress("### DELETING RESOURCE FOR BLUEPRINT ###", tasks_done=2)

    set_progress("ALL Tests completed!", tasks_done=3)
    