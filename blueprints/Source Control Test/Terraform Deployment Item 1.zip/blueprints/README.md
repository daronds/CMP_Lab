Top-level folder for sharing CloudBolt blueprints.

These can be exported from CloudBolt from a blueprint's details page by
pressing the "Export" button. They can be imported in the CloudBolt UI (as of v6.1-alpha3) or by running
/opt/cloudbolt/api/api_samples/python_client/samples/import_resource.py on the
CloudBolt server.
