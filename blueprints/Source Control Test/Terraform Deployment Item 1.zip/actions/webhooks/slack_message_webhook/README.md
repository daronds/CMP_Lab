This webhook posts a completion message to [Slack](https://slack.com) when server provisioning has completed.

More information on Slack Webhooks is available in their [API documentation](https://api.slack.com/incoming-webhooks). You can receive your unique Slack Webhook URL by setting up an [incoming webhook integration](https://my.slack.com/services/new/incoming-webhook/) for your Slack team.
