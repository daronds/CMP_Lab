1. Needs to add this script inside Recurring Job
2. Needs to set schedule time along with profile id and recipient email.
<br /> Follow the screenshots-

    ![Getting Started](./images/1.png)

    ![Getting Started](./images/2.png)

    ![Getting Started](./images/3.png)

    ![Getting Started](./images/4.png)

    ![Getting Started](./images/5.png)

    ![Getting Started](./images/6.png)

    ![Getting Started](./images/7.png)

    ![Getting Started](./images/8.png)

    ![Getting Started](./images/9.png)
