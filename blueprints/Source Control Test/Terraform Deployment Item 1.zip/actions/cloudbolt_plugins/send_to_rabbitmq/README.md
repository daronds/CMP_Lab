# CloudBolt Send to RabbitMQ plugin

## Requirements

To run this code you need `pika` library version 0.10.0 To install it run

    pip install pika==0.10.0
