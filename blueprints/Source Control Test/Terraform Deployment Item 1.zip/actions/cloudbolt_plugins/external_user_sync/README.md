This directory is for CB Plugins used for external user synchronization.  These plugins run at the time an external user authenticates to CB and can add/remove privliges in their account according to their roles in some external system (such as AD).

See the [CloudBolt docs](http://docs.cloudbolt.io/) for more information on User Permission Synchronization.

We welcome your contributions to this repository as well as [your questions](mailto:support@cloudbolt.io) about our plugins.
