These plugins can be used to build up and tear down an Azure website service.

Each requires some Parameters to exist in the CB database.  See the source code
for details.
