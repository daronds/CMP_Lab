#!/bin/bash

# Used in the CentOS Development Environment Blueprint

yum install git zsh vim-enhanced -y
